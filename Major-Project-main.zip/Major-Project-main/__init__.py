from flask import Flask, request, render_template, redirect, url_for, Response
from mysql.connector import MySQLConnection, Error
import cv2
import numpy as np
import pygame
import face_recognition
import mysql.connector
import io
from io import BytesIO
import base64
import time
import PIL.Image
from PIL import Image


app = Flask(__name__)


pygame.init()
pygame.mixer.init()

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp3'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


video_capture = cv2.VideoCapture(0)


def create_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="shravan@03",
            database="shrav"
        )
        return connection
    except Error as e:
        print(f"The error '{e}' occurred")
        return None


def decode_base64_image(image_data):
    try:
        image_bytes = base64.b64decode(image_data)
        nparr = np.frombuffer(image_bytes, np.uint8)
        # image = cv2.imdecode(nparr, 0)
        file_like = BytesIO(image_data)
        img = PIL.Image.open(file_like)
        return img
    except Exception as e:
        print("Error decoding image:", e)
        return "None1"


mydb = create_connection()
mycursor = mydb.cursor()

mycursor.execute("SELECT avatar, fname, ringtone FROM users")
known_faces = mycursor.fetchall()

known_face_encodings = []
known_face_names = []
known_face_mp3 = []
for avatar, fname, ringtone in known_faces:
    try:
        # Decode the base64 encoded image data
        image = decode_base64_image(avatar)
        if image is not None:
            # Convert the image to RGB (face_recognition requires RGB images)
            rgb_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGBA2RGB)

            # Find face encodings
            face_encoding = face_recognition.face_encodings(rgb_image)[0]

            # Append the processed face encoding, name, and mp3 file to their respective lists
            known_face_encodings.append(face_encoding)
            known_face_names.append(fname)
            known_face_mp3.append(ringtone)
        else:
            print("Failed to decode image:", fname)
    except Exception as e:
        print("Error processing image:", fname, "-", e)

familiar_ringtone_path = 'C:/Nilede/Major-Project/familiar.mp3'
unfamiliar_ringtone_path = 'C:/Nilede/Major-Project/unfamiliar.mp3'
pygame.mixer.music.load(familiar_ringtone_path)
pygame.mixer.music.load(unfamiliar_ringtone_path)

face_detected = False
start_time = time.time()  # Initialize start time
time_limit = 5
ringtone_played = False


def detect_faces():
    global face_detected
    global start_time
    global ringtone_played

    while True:
        ret, frame = video_capture.read()

        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(
            rgb_small_frame, face_locations)

        face_names = []
        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(
                known_face_encodings, face_encoding)
            name = "Unknown"
            mp3_file = None

            if True in matches:
                first_match_index = matches.index(True)
                name = known_face_names[first_match_index]
                mp3_file = known_face_mp3[first_match_index]

            face_names.append((name, mp3_file))

        # Check if any known face is detected
        known_face_detected = any(
            [name != "Unknown" for name, _ in face_names])

        # Check if it's time to play the ringtone
        if time.time() - start_time >= time_limit:
            # If a known face is detected, play the corresponding MP3 file
            for name, mp3_file in face_names:
                if name != "Unknown" and mp3_file is not None:
                    pygame.mixer.music.load(mp3_file)
                    pygame.mixer.music.play()
                    # Reset the start time
                    start_time = time.time()
                    # Mark ringtone as played
                    ringtone_played = True
                    break
            else:  # If no known face is detected, play the unfamiliar ringtone
                if not ringtone_played:  # Ensure the ringtone is not played repeatedly
                    pygame.mixer.music.load(unfamiliar_ringtone_path)
                    pygame.mixer.music.play()
                    # Reset the start time
                    start_time = time.time()
                    # Mark ringtone as played
                    ringtone_played = True
        # Reset the start time if no faces are detected
        if len(face_locations) == 0:
            start_time = time.time()
            ringtone_played = False
            pygame.mixer.music.stop()

        for (top, right, bottom, left), (name, _) in zip(face_locations, face_names):
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.rectangle(frame, (left, bottom - 35),
                          (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(frame, name, (left + 6, bottom - 6),
                        font, 1.0, (255, 255, 255), 1)

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


def fetch_users(connection):
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users")
        users = cursor.fetchall()
        return users
    except Error as e:
        print(f"Error fetching users: {e}")
        return None


def base64_encode(data):
    return base64.b64encode(data).decode('utf-8')


app.jinja_env.filters['b64encode'] = base64_encode


def insert_data(connection, avatar, fname, lname, ringtone):
    try:
        cursor = connection.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                avatar LONGBLOB,
                fname VARCHAR(255),
                lname VARCHAR(255),
                ringtone VARCHAR(255)
            )
        """)
        connection.commit()

        cursor.execute("INSERT INTO users (avatar, fname, lname, ringtone) VALUES (%s, %s, %s, %s)",
                       (avatar, fname, lname, ringtone))
        connection.commit()
    except Error as e:
        print(f"Error inserting data: {e}")


def delete_user_data(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        connection.commit()
        return True
    except Error as e:
        print(f"Error deleting user data: {e}")
        return False


def get_user_data(connection, user_id):
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user_data = cursor.fetchone()
        return user_data
    except Error as e:
        print(f"Error fetching user data: {e}")
        return None


def update_user_data(user_id, form_data, avatar=None):
    try:
        connection = create_connection()
        if connection:
            cursor = connection.cursor()
            if avatar:
                cursor.execute("UPDATE users SET avatar=%s, fname=%s, lname=%s, ringtone=%s WHERE id=%s",
                               (avatar, form_data['fname'], form_data['lname'], form_data['ring'], user_id))
            else:
                cursor.execute("UPDATE users SET fname=%s, lname=%s, ringtone=%s WHERE id=%s",
                               (form_data['fname'], form_data['lname'], form_data['ring'], user_id))
            connection.commit()
            connection.close()
            return True
    except Error as e:
        print(f"Error updating user data: {e}")
    return False


@app.route('/')
def index():
    return render_template('cam.html')


@app.route('/home')
def home():
    return render_template('main.html')


@app.route('/video_feed')
def video_feed():
    return Response(detect_faces(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/settings')
def settings():
    return render_template('setting.html')


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':
        avatar = request.files['avatar'].read()
        fname = request.form['fname']
        lname = request.form['lname']
        ringtone = request.form['ring']

        connection = create_connection()

        if connection:
            insert_data(connection, avatar, fname, lname, ringtone)
            connection.close()

        return redirect(url_for('profile'))

    connection = create_connection()

    if connection:
        users = fetch_users(connection)
        connection.close()
        return render_template('card.html', users=users)
    else:
        return "Database connection failed"


@app.route('/adduser', methods=['GET', 'POST'])
def adduser():
    if request.method == 'POST':
        avatar = request.files['avatar'].read()
        fname = request.form['fname']
        lname = request.form['lname']
        ringtone = request.form['ring']

        connection = create_connection()

        if connection:
            insert_data(connection, avatar, fname, lname, ringtone)
            connection.close()

        return redirect(url_for('profile'))

    connection = create_connection()

    if connection:
        users = fetch_users(connection)
        connection.close()
        return render_template('adduser.html', users=users)
    else:
        return "Database connection failed"


@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    connection = create_connection()
    if connection:
        if delete_user_data(connection, user_id):
            connection.close()
            return redirect(url_for('profile'))
    return "Failed to delete user"


@app.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    if request.method == 'POST':
        avatar = request.files['avatar'].read()
        if update_user_data(user_id, request.form, avatar):
            return redirect(url_for('profile'))

    connection = create_connection()
    if connection:
        user_data = get_user_data(connection, user_id)
        connection.close()
        if user_data:
            return render_template('updateuser.html', user=user_data)
    return "User not found"


if __name__ == '__main__':
    app.run(debug=True)  # You can set debug=False in production
